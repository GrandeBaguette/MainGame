﻿using UnityEngine;
using System.Collections;
using PlayerStats;

public class EnemyScript : MonoBehaviour {

    PlayerStats ps = new PlayerStats(0);
    // Use this for initialization
    void Start () {
        
	}
	
	// Update is called once per frame
	void FixedUpdate () {
	
	}

    void OnTriggerEnter(Collider other) {

        Debug.Log("Collision Detected");

        if (other.gameObject.CompareTag("Player")) {
            ps.PlayerStats(1);
        }
    }
}
