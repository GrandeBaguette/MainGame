﻿using UnityEngine;
using System.Collections;

public class PlayerStats : MonoBehaviour {

    public int playerHP = 1;
	// Use this for initialization

    public PlayerStats(int damage) {
        playerHP -= damage;
    }
	void Awake () {
	
	}
	
	// Update is called once per frame
	void FixedUpdate () {
	
	}
}
